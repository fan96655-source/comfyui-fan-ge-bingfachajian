# gpt-image-2/gpt-image-2.5接口

## OpenAPI Specification

```yaml
openapi: 3.0.1
info:
  title: ''
  description: ''
  version: 1.0.0
paths:
  /v1/api/generate:
    post:
      summary: gpt-image-2/gpt-image-2.5接口
      deprecated: false
      description: |-
        基础节点：
        https://grsaiapi.com                (全球节点)
        https://grsai.dakka.com.cn     (国内节点)

        例子：
        https://grsaiapi.com/v1/api/generate
        https://grsai.dakka.com.cn/v1/api/generate
      tags:
        - Grsai图片/视频生成接口
      parameters:
        - name: base_url
          in: path
          description: ''
          required: true
          schema:
            type: string
        - name: Authorization
          in: header
          description: 请前往以下页面获取APIKEY：https://grsai.ai/zh/dashboard/api-keys
          required: false
          example: Bearer sk-xxxxxxxxxxx
          schema:
            type: string
      requestBody:
        content:
          application/json:
            schema:
              type: object
              properties:
                model:
                  type: string
                  title: 模型名称
                  description: |-
                    支持以下模型
                    gpt-image-2
                    gpt-image-2-vip
                    gpt-image-2.5
                    gpt-image-2.5-flare
                    gpt-image-2.5-sunburst
                prompt:
                  type: string
                  title: 提示词
                images:
                  type: array
                  items:
                    type: string
                  title: 参考图
                  description: 支持base64与url链接
                aspectRatio:
                  type: string
                  title: 比例
                  description: |-
                    分辨率参数说明
                      gpt-image-2：支持比例（如 "16:9"）或1K像素值（如 "1024x1024"）
                      gpt-image-2-vip/gpt-image-2.5-flare/gpt-image-2.5-sunburst：支持1-4K像素值（如 "1024x1024"、"2048x2048"），不支持比例

                    自定义像素值约束（仅限 vip 模型）
                       最大边长必须小于或等于3840px
                       两条边都必须是16的倍数
                       长边与短边之比不得超过 3:1
                       总像素数必须至少为 655,360且不得超过 8,294,400


                     gpt-image-2-vip/gpt-image-2.5-flare/gpt-image-2.5-sunburst比例参考（1K、2K、4K）：
                    auto
                    1:1：1024x1024、2048x2048、2880x2880
                    16:9：1280x720、2048x1152、3840x2160
                    9:16：720x1280、1152x2048、2160x3840
                    4:3：1152x864、2304x1728、3264x2448
                    3:4：864x1152、1728x2304、2448x3264
                    3:2：1536x1024、2048x1360、3504x2336
                    2:3：1024x1536、1360x2048、2336x3504
                    5:4：1120x896、2240x1792、3200x2560
                    4:5：896x1120、1792x2240、2560x3200
                    21:9：1456x624、2912x1248、3840x1648
                    9:21：624x1456、1248x2912、1648x3840
                    1:3：688x2048、1280x3840
                    3:1：2048x688、3840x1280
                    2:1：1536x768、3072x1536、3840x1920
                    1:2：768x1536、1536x3072、1920x3840

                     gpt-image-2比例参考：
                    auto
                    1:1：1024x1024
                    16:9：1672 x941
                    9:16：941x1672 
                    4:3：1443x1090
                    3:4：1090x1443
                    3:2：1536x1024
                    2:3：1024x1536
                    5:4：1408x1120
                    4:5：1120x1408
                    21:9：1920x832
                    9:21：832x1920
                    1:2：896x1792
                    2:1：1792x896
                replyType:
                  type: string
                  title: 回复类型
                  description: |-
                    支持参数
                    json（返回json）
                    stream（返回stream）
                    async（异步轮询）
                    异步生成结果查询接口：https://qmy27nhsd9.apifox.cn/452409577e0
                quality:
                  type: string
                  title: 质量
              required:
                - model
                - prompt
              x-apifox-orders:
                - model
                - prompt
                - images
                - aspectRatio
                - quality
                - replyType
            example:
              model: gpt-image-2
              prompt: 生成一张边牧与古牧正在抖音直播间直播带货截图
              images: []
              aspectRatio: 1024x1024
              quality: auto
              replyType: json
      responses:
        '200':
          description: ''
          content:
            application/json:
              schema:
                type: object
                properties:
                  id:
                    type: string
                    title: 任务id
                  status:
                    type: string
                    title: 状态
                    description: |
                      任务状态
                      running  (进行中)
                      violation  (违规)
                      succeeded (生成成功)
                      failed (任务失败)
                  results:
                    type: array
                    items:
                      type: object
                      properties:
                        url:
                          type: string
                          title: 图片/视频链接
                      x-apifox-orders:
                        - url
                  progress:
                    type: integer
                    title: 进度
                    description: 0~100
                  error:
                    type: string
                    title: 报错信息
                required:
                  - id
                  - status
                x-apifox-orders:
                  - id
                  - status
                  - progress
                  - results
                  - error
              example:
                id: 14-5f3cf761-a4bb-486a-8016-77f490998f80
                status: succeeded
                results:
                  - url: >-
                      https://file1.aitohumanize.com/file/fcdd2d07449d438d9d69d450f5626976.png
          headers: {}
          x-apifox-name: 成功
        '400':
          description: ''
          content:
            application/json:
              schema:
                type: object
                properties:
                  id:
                    type: string
                  status:
                    type: string
                    title: 状态
                    description: |-
                      状态
                      violation（违规）
                      failed（失败）
                  error:
                    type: string
                    title: 报错信息
                required:
                  - id
                  - status
                  - error
                x-apifox-orders:
                  - id
                  - status
                  - error
              example:
                id: 12-1f771fbf-f23a-4b89-a7d0-a98ba9862edb
                status: failed
                error: generate failed
          headers: {}
          x-apifox-name: 报错
        x-200:异步生成返回结果:
          description: ''
          content:
            application/json:
              schema:
                type: object
                properties:
                  id:
                    type: string
                    title: 任务id
                    description: |-
                      通过该id调用异步结果查询接口
                      接口文档：https://qmy27nhsd9.apifox.cn/452409577e0
                  status:
                    type: string
                    title: 状态
                  01KQS7HP0FA36FTFVEPEF2D10R:
                    type: string
                required:
                  - id
                  - status
                x-apifox-orders:
                  - id
                  - status
                  - 01KQS7HP0FA36FTFVEPEF2D10R
              example:
                id: 6-f671fc51-d5d7-4eff-a1c7-26e612fe08ab
                status: running
          headers: {}
          x-apifox-name: 异步生成返回结果
      security: []
      x-apifox-folder: Grsai图片/视频生成接口
      x-apifox-status: released
      x-run-in-apifox: https://app.apifox.com/web/project/8212034/apis/api-452409160-run
components:
  schemas: {}
  securitySchemes: {}
servers: []
security: []

```